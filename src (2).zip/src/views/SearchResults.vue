<template>
    <div id="app">
      <HeaderView />
      <main>
        <v-container>
          <section>
            <div class="search-contents">
              <h2>⭐ Let's go ⭐</h2>
              <ul class="favorite-list">
                <v-row>
                  <v-col cols="12" md="4" v-for="(item, index) in dataList" :key="index">
                    <div class="list-card">
                      <div class="card-contents">
                        <span class="card-id"> {{ item.ID }}</span>
                        <span class="card-name"> {{ item.Name }}</span>
                        <span class="card-area"> {{ item.Area }}</span>
                        <span class="card-category"> {{ item.Category }}</span>
                      </div>
                    </div>
                  </v-col>
                </v-row>
              </ul>
            </div>
          </section>
        </v-container>
      </main>
      <FooterView />
    </div>
  </template>
   
  <script>
  import axios from "axios";
  import HeaderView from '@/components/HeaderView.vue';
  import FooterView from '@/components/FooterView.vue';
   
  export default {
    name: 'SearchResults',
    components: {
      HeaderView,
      FooterView,
    },
    data() {
      return {
        selectedArea: '',
        selectedCategory: '',
        dataList: [], // APIから取得したデータを格納する配列
      };
    },
    created() {
      // クエリパラメータを取得
      this.selectedArea = this.$route.query.area || '';
      this.selectedCategory = this.$route.query.category || '';
      console.log("クエリパラメータ: ", this.selectedArea, this.selectedCategory);
   
      // 画面切り替え後にAPIを実行
      this.fetchResults();
    },
    methods: {
      async fetchResults() {
        try {
          console.log("APIリクエストを開始します");
   
          const response = await axios.get(
            "https://m3h-ikari-functionapp729.azurewebsites.net/api/SELECT",
            {
              params: {
                area: this.selectedArea,
                category: this.selectedCategory,
              },
            }
          );
   
          console.log("APIレスポンスを受信:", response.data);
   
          if (response.data && response.data.List) {
            this.dataList = response.data.List;
            console.log("dataListが更新されました:", this.dataList);
          } else {
            console.error("APIから期待されるデータ形式が返されませんでした");
          }
   
        } catch (error) {
          console.error("データの取得に失敗しました:", error);
        }
      },
    },
  };
  </script>
   
  <style scoped>
  /* 既存のスタイルをそのまま使用 */
  </style>