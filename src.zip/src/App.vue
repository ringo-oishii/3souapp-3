<template>
  <div id="app">
        <!-- <router-link to="/">ホーム</router-link>
    <router-link to="/area-results">エリア</router-link>
    <router-link to="/category-results">アバウト</router-link> -->
 
    <router-view/>
<!--     <input v-model="value" />
 -->    <!-- <HomeView /> -->

  </div>
</template>

<script>
//import HomeView from './components/HomeView.vue';

export default {
  components: {
      //HomeView
  }
  }
</script>

<style>



</style>


