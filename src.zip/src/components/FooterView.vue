<template>
    <footer>
      <p>©What do you eat?. All rights reserved.</p>
      <div class="footer-links">
        <a href="#">利用規約</a>
        <a href="#">プライバシーポリシー</a>
        <a href="#">お問い合わせ</a>
      </div>
    </footer>
  </template>
  
  <script>
  export default {};
  </script>
  
  <style scoped>
  footer {
    margin-top: 40px;
    padding: 20px;
    background-color: #fbf9c2;
    color: #5d5d63;
  }
  
  .footer-links {
    margin-top: 10px;
  }
  
  .footer-links a {
    margin-right: 15px;
    color: #e45479;
    text-decoration: none;
  }
  </style>
  